#' @importFrom utils tail
#' @importFrom stats as.formula formula median model.matrix na.omit complete.cases 
#' pnorm qnorm quantile reorder rnorm sd vcov weighted.mean
zzz <- function(){
  # Nothing
  
}