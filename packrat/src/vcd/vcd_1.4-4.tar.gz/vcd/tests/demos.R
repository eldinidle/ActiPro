library(vcd)
demo(discrete)
demo(twoway)
demo(mosaic)
demo(mondrian)
demo(strucplot)
demo(hullternary)

